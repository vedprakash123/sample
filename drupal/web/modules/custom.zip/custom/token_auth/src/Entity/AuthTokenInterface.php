<?php

namespace Drupal\token_auth\Entity;

use Drupal\Core\Config\Entity\ConfigEntityInterface;

/**
 * Provides an interface for defining Authentication Token entities.
 */
interface AuthTokenInterface extends ConfigEntityInterface {

  // Add get/set methods for your configuration properties here.
}
